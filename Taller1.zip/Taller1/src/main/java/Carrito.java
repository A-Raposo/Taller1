import java.util.ArrayList;

public class Carrito {
    public static void main(String[] args) {
        carrito();
    }
    public static void carrito(){
        ArrayList<Integer> carrito = new ArrayList<>();
        int largoCarrito = random(20)+1;
        productos(carrito,largoCarrito);


    }
    public static void productos(ArrayList<Integer> a,int largoCarrito){
        ArrayList<Integer>precios = new ArrayList<>();
        for (int i = 0; i <= largoCarrito; i++) {
            int total = random(15);
            a.add(total);
            total = total*150;
            precios.add(500 + total);
        }
        int p=0;
        for (int i = 0; i < a.size(); i++) {
            p=p+a.get(i);

        }
        System.out.println("El carrito contiene " + p + " productos");
    }
    public static int random(int a){
        int random = ((int)(Math.random()*a));
        return random;
    }
}
